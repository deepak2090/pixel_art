import pixel_art.examples, pixel_art.pixels
